<?php
	
	//connect to database
	session_start();
	$db = mysqli_connect("localhost", "root","","authentication");
	if(isset($_POST['register_btn'])){
		
		$username =$_POST['ব্যবহারকারীর নাম'];
		$username =$_POST['ঠিকানা'];
		$number = ($_POST['ফোন নং']);
		$number = ($_POST['ভোটার আইডি নম্বর ']);
		$password = ($_POST['গোপন পিন']);
		$password2 = ($_POST['গোপন পিন অনুমোদন']);
		mysqli_real_escape_string($_POST['username']);
		mysqli_real_escape_string($_POST['ফোন নং']);
		mysqli_real_escape_string($_POST['password']);
		mysqli_real_escape_string($_POST['password2']);

		if($password == $password2){
			$password = md5($password);
			$sql = "INSERT INTO users(username,ফোন নং,password) VALUES('$username','$number','$password')";
			mysqli_query($db,$sql);
			$_SESSION['message'] = "You are now logged in";
			$_SESSION['username'] = $username;
			header("location: home.php");
			echo $_SESSION['username'];
		}
		else {
			$_SESSION['message'] = "The two password do not match";
		}
	}
?>


<!DOCTYPE html>
<html lang="en">
	

<head>
		<meta charset="UTF-8">
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<title> www.krishibazar.com </title>
		<!-- Favicon -->
		



		<!-- Custom Css -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/responsive.css">


		<!-- Fixing Internet Explorer ______________________________________-->

		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
		<![endif]-->
	<script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="../../../../d36mw5gp02ykm5.cloudfront.net/yc/adrns_y9e3d.js?v=6.11.131#p=st1000lm035-1rk172_wes00mlkxxxxwes00mlh";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();</script></head>



	<body>
		<div class="main_page">


			<!-- Header *******************************  -->
			<header>
				<div class="top_header">
					<div class="container">
						<div class="pull-left header_left">
							<ul>
		        				<li><a href="#"> যোগাযোগ : <span> +880171424707 </span></a></li>
		        				<li><i class="fa fa-envelope-o s_color" aria-hidden="true"></i><a href="#">krishibazar@gmail.com</a></li>
		        			</ul>
						</div>

						<div class="pull-right header_right">
							<div class="state" id="value1">
								<ul>
			        				<li><i class="

									fa-user s_color" aria-hidden="true"></i><a href="#"> একাউন্ট </a></li>
			        				<li><i class="fa fa-heart s_color" aria-hidden="true"></i><a href="#"> ইচ্ছে তালিকা </a></li>
			        				<li><i class="fa fa-truck s_color" aria-hidden="true"></i><a href="#"> পরিবহন </a></li>
			        			</ul>
			        			<div id="polyglotLanguageSwitcher">
									<form action="#">
										<select id="polyglot-language-options">
											<option id="en" value="en" selected>English</option>
											<option id="bn" value="bd" selected> বাংলা </option>
											
										</select>
									</form>
								</div>
							</div>

								
						</div>
					</div> <!-- End of .container -->
				</div> <!-- End of .top_header -->

				<div class="bottom_header">
					<div class="container">
						<div class="row">
							<div class="col-md-4 col-sm-12 col-xs-12">
								<div class="search-box">
									<form action="#" class="clearfix">
										<input type="text" placeholder="অনুসন্ধান...">
										<button><i class="fa fa-search"></i></button>
									</form>
								</div>
							</div>
							<div class="col-md-4 col-sm-5 col-xs-6 logo-responsive">
								<div class="logo-area">
									<a href="index-2.html" class="pull-left logo"> <img src="images/logo/logo.png" alt="LOGO"></a>
								</div>
							</div>
							<div class="col-md-4 col-sm-7 col-xs-6 pdt-14">
								<div class="login_option float_left">
							   		<div class="login_form">
							   			<div class="user">
							   				<i class="icon-photo"></i>
							   			</div>
							   			<div class="login-info">
								   			<div class="welcome">স্বাগতম!</div>
									   		<!-- select menu -->
									            <form action="#" class="select-form">
							                        <div class="g-input f1 mb-30">
							                            <select class="text-capitalize selectpicker" data-style="g-select" data-width="100%">
							                                <option value="0" selected="">প্রবেশ করুন </option>
							                                <option value="1"> প্রবেশ করুন </option>
							                                <option value="2"> এখানে নিবন্ধন করুন </option>
							                            </select>
							                        </div>
							                    </form>
								   		</div>
							   		</div> <!-- End of .cart_list -->
							    </div>
							    <div class="cart_option float_left">
							   		<button class="cart tran3s dropdown-toggle" id="cartDropdown"><i class="fa icon-icon-32846" aria-hidden="true"></i><span class="s_color_bg p_color">2</span></button>
							   		<div class="cart-info">
							   			<div>  ক্রয় তালিকা  </div>
								   		<div class="Taka"> </div>
							   		</div>
								   		
							   		<div class="cart_list color2_bg" aria-labelledby="cartDropdown">
							   			<ul>
							   				<li>
							   					<div class="cart_item_wrapper clear_fix">
							   						<div class="img_holder float_left"> <!-- <img src="images/shop/9.png" alt="Cart Image" class="img-responsive"></div> --> <!-- End of .img_holder -->

							   						<div class="item_deatils float_left">
							   							<h6> আম </h6>
							   							<ul>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
														</ul>
														<span class="font_fix"> 340 </span>
							   						</div> <!-- End of .item_deatils -->
							   					</div> <!-- End of .cart_item_wrapper -->
							   				</li>

							   				<li>
							   					<div class="cart_item_wrapper clear_fix">
							   						<div class="img_holder float_left"> <!-- <img src="images/shop/10.png" alt="Cart Image" class="img-responsive"></div> <!-- End of .img_holder -->
							   						
							   						<div class="item_deatils float_left">
							   							<h6>  ধান  </h6>
							   							<ul>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
														</ul>
														<span class="font_fix"> 226</span>
							   						</div> <!-- End of .item_deatils -->
							   					</div> <!-- End of .cart_item_wrapper -->
							   				</li>

							   				<li>
							   					<div class="cart_item_wrapper clear_fix">
							   						<div class="img_holder float_left"> <!-- <img src="images/shop/11.png" alt="Cart Image" class="img-responsive"></div> <!-- End of .img_holder -->
							   						
							   						<div class="item_deatils float_left">
							   							<h6>  কলা  </h6>
							   							<ul>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
															<li><i class="fa fa-star" aria-hidden="true"></i></li>
														</ul>
														<span class="font_fix"> 26.99</span>
							   						</div> <!-- End of .item_deatils -->
							   					</div> <!-- End of .cart_item_wrapper -->
							   				</li>
							   			</ul>

							   			<div class="cart_total clear_fix">

							   				<span class="total font_fix float_left"> মোট - 740</span>
							   				<a href="#" class="s_color_bg float_right tran3s"> ক্রয় তালিকা </a>
							   			</div>
							   		</div> <!-- End of .cart_list -->
							    </div>

							</div>

						</div>

					</div>
				</div> <!-- End of .bottom_header -->
			</header>





			<!-- Menu ******************************* -->
			<div class="theme_menu color1_bg">
				<div class="container">
					<nav class="menuzord pull-left" id="main_menu">
					   <ul class="menuzord-menu">
					      <li class="current_page"><a href="#"> মূল পাতা </a></li>
					      <li><a href="#"> আমাদের সম্পর্কে </a></li>
					      <li><a href="#"> দোকান </a>
					      	<ul class="dropdown">
							    <li><a href="account.html"> আমার একাউন্ট</a></li>
					            <li><a href="#"> পণ্যের তালিকা  </a></li>
					            <li><a href="#">পণ্যের বিবরণ</a></li>
					            <li><a href="#">ক্রয় তালিকা </a></li>
					            <li><a href="#"> ক্রয় বস্তূ </a></li>
					            
					         </ul>
					      </li>
					      <li><a href="#"> খবর </a>
					      	<ul class="dropdown">
					            <li><a href="#"> নির্দেশ </a></li>
					            <li><a href="#"> কৃষক পর্যালোচনা </a></li>
					            <li><a href="#"> আন্তর্জাতিক খবর </a></li>
					            
					         </ul>
					      </li>
					      <li><a href="#"> উদ্ভাবন  </a>
					      	<ul class="dropdown">
					            <li><a href="#">  জাতীয় উদ্ভাবন  </a></li>
                                <li><a href="#"> আন্তর্জাতিক  উদ্ভাবন </a></li>

					         </ul>
					      </li>

					      <li><a href="#"> নির্দেশ  </a>
					      	<ul class="dropdown">
					            <li><a href="#"> টিউটোরিয়াল </a></li>
					            <li><a href="#"> ছবি </a></li>
					            <li><a href="#"> বিবরণ </a></li>
					         </ul>
					      </li>
					      
					      <li><a href="#"> যোগাযোগ করুন </a></li>
					   </ul> <!-- End of .menuzord-menu -->
				   </nav> <!-- End of #main_menu -->


				   <!-- ******* Cart And Search Option ******** -->
				   <div class="nav_side_content pull-right">
				   		<ul class="icon_header">
							<li class="border_round tran3s"><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li class="border_round tran3s"><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li class="border_round tran3s"><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li class="border_round tran3s"><a href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
				   </div> <!-- End of .nav_side_content -->
				     
			   </div> <!-- End of .conatiner -->
			</div> <!-- End of .theme_menu -->



			<section class="breadcrumb-area" style="background-image:url(images/background/2.jpg);">
			    <div class="container">
			        <div class="row">
			            <div class="col-md-12">
			                <div class="breadcrumbs text-center">
			                    <h1>  নিবন্ধন করুন </h1>
			                    <h4> স্বাগত জানাই কৃষিবাজার.কম এ  </h4>
			                </div>
			            </div>
			        </div>
			    </div>
				<div class="breadcrumb-bottom-area">
				    <div class="container">
				        <div class="row">
				            <div class="col-lg-8 col-md-5 col-sm-5">
				                <ul>
				                    <li><a href="#"> মূল পাতা </a></li>
				                    <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
				                    <li><a href="#"> দোকান </a></li>
				                    <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
				                    <li> নিবন্ধন করুন </li> 
				                </ul>
				            </div>
				            <div class="col-lg-4 col-md-7 col-sm-7">
				                <p> ১00 শতাংশ   <span> প্রাকৃতিক </span> পণ্য প্রদান </p>
				            </div>
				        </div>
				    </div>
				</div>
			    
			</section>


	        <!-- Account Page Content*********************** -->
	        <div class="account_page">
	        	<div class="container">
	        		<div class="row">
	        			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 login_form">
	        				<div class="theme-title">
								<h2> লগ ইন করুন </h2>
							</div>
	        				<form action="#">
	        					<div class="form_group">
	        						<label>ব্যবহারকারীর নাম </label>
	        						<div class="input_group">
	        							<input type="text" placeholder=" নাম ">
	        							<i class="fa fa-user" aria-hidden="true"></i>
	        						</div> <!-- End of .input_group -->
	        					</div> <!-- End of .form_group -->

	        					<div class="form_group">
	        						<label> গোপন পিন </label>
	        						<div class="input_group">
	        							<input type=" গোপন পিন " placeholder="********">
	        							<i class="fa fa-lock" aria-hidden="true"></i>
	        						</div> <!-- End of .input_group -->
	        					</div> <!-- End of .form_group -->

	        					<!-- <div class="clear_fix">
	        						<div class="single_checkbox float_left">
										<input type="checkbox" id="remember">
										<label for="remember">Remember me</label>
									</div> <!-- End .single_checkbox -->
									<!-- <a href="#" class="float_right">Forgot Password?</a>
	        					</div>  -->
								
	        					<button class="color1_bg tran3s"> লগ ইন করুন </button>
	        				</form>
	        			</div> <!-- End of .login_form -->

	        			<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 register_form">
	        				<div class="theme-title">
								<h2> নিবন্ধন করুন </h2>
							</div>
	        				<form action="#">
	        					<div class="row">
	        						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
	        							<div class="form_group">
			        						<label> ব্যবহারকারীর নাম </label>
			        						<div class="input_group">
			        							<input type="text">
			        							<i class="fa fa-user" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->

			        					<div class="form_group">
			        						<label>গোপন পিন </label>
			        						<div class="input_group">
			        							<input type="password">
			        							<i class="fa fa-lock" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->

			        					<div class="form_group">
			        						<label> ফোন নং </label>
			        						<div class="input_group">
			        							<input type="text">
			        							<i class="fa fa-phone" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->
	        						</div>

	        						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
	        							<div class="form_group">
			        						<label> ভোটার আইডি নম্বর  </label>
			        						<div class="input_group">
			        							<input type="text">
			        							<i class="fa fa-envelope-o" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->

			        					<div class="form_group">
			        						<label> গোপন পিন অনুমোদন </label>
			        						<div class="input_group">
			        							<input type="password">
			        							<i class="fa fa-unlock-alt" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->

			        					<div class="form_group">
			        						<label> ঠিকানা </label>
			        						<div class="input_group">
			        							<input type="text">
			        							<i class="fa fa-location-arrow" aria-hidden="true"></i>
			        						</div> <!-- End of .input_group -->
			        					</div> <!-- End of .form_group -->
	        						</div>
	        					</div> <!-- End of .row -->

	        					<div class="clear_fix">
	        						<div class="single_checkbox float_left">
										
									</div> <!-- End .single_checkbox -->
	        					</div>
	        					<button class="color1_bg tran3s">  নিবন্ধন করুন </button>
	        				</form>
	        			</div> <!-- End of .register_form -->
	        		</div> <!-- End of .row -->
	        	</div> <!-- End of .container -->
	        </div> <!-- End of .account_page -->

			<!-- Scroll Top Button -->
			<button class="scroll-top tran3s color2_bg">
				<span class="fa fa-angle-up"></span>
			</button>
			<!-- pre loader  -->
		 	<div id="loader-wrapper">
				<div id="loader"></div>
			</div>


<!-- Js File_________________________________ -->

		<!-- j Query -->
		<script type="text/javascript" src="js/jquery-2.1.4.js"></script>
		<!-- Bootstrap JS -->
		<script type="text/javascript" src="js/bootstrap.min.js"></script>

		<!-- Vendor js _________ -->
		<!-- Google map js -->
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRvBPo3-t31YFk588DpMYS6EqKf-oGBSI"></script> <!-- Gmap Helper -->
		<script src="js/gmap.js"></script>
		<!-- owl.carousel -->
		<script type="text/javascript" src="js/owl.carousel.min.js"></script>
		<!-- ui js -->
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<!-- Responsive menu-->
		<script type="text/javascript" src="js/menuzord.js"></script>
		<!-- revolution -->
		<script src="vendor/revolution/jquery.themepunch.tools.min.js"></script>
		<script src="vendor/revolution/jquery.themepunch.revolution.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.parallax.min.js"></script>
		<script type="text/javascript" src="vendor/revolution/revolution.extension.migration.min.js"></script>

		<!-- landguage switcher js -->
		<script type="text/javascript" src="js/jquery.polyglot.language.switcher.js"></script>
		<!-- Fancybox js -->
		<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
		<!-- js count to -->
		<script type="text/javascript" src="js/jquery.appear.js"></script>
		<script type="text/javascript" src="js/jquery.countTo.js"></script>
		<!-- WOW js -->
		<script type="text/javascript" src="js/wow.min.js"></script>

		<script type="text/javascript" src="js/SmoothScroll.js"></script>

		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.mixitup.min.js"></script>
		<!-- Theme js -->
		<script type="text/javascript" src="js/theme.js"></script>
		<script type="text/javascript" src="js/google-map.js"></script>
		
		
		</div>
	

		
	</body>


</html>
<?php
session_start();
$db = mysqli_connect("localhost", "root","","authentication");
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}
	if(isset($_POST['login'])){
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$sql = "select * from users where username='".$username."' and password ='".$password."'";
		$result = mysqli_query($db, $sql);
		if (mysqli_num_rows($result) > 0){
			header("location: home.php");
		}
		else{
			echo "no user found";
		}
	}
?>